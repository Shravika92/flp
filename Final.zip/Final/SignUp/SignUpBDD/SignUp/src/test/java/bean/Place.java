package bean;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;

public class Place {

	@FindBy(xpath="//p[contains(text(),'*First Name is required')]")
	@CacheLookup
	private WebElement errfname;

	
	@FindBy(xpath="//p[contains(text(),'*Last Name is required')]")
	@CacheLookup
	private WebElement errlname;
	
	@FindBy(xpath="//p[contains(text(),'*Password is required')]")
	@CacheLookup
	private WebElement errpwd;
	
	@FindBy(xpath="//p[contains(text(),'*Confirm Password is required')]")
	@CacheLookup
	private WebElement errcpwd;
	
	@FindBy(xpath="//p[contains(text(),'*Mobile Number is required')]")
	@CacheLookup
	private WebElement errphnum;
	
	@FindBy(xpath="//p[contains(text(),'*Email is required')]")
	@CacheLookup
	private WebElement erremail;
	
	@FindBy(xpath="//p[contains(text(),'*Address is required')]")
	@CacheLookup
	private WebElement erraddr;
	
	@FindBy(xpath="//p[contains(text(),'*City is required')]")
	@CacheLookup
	private WebElement errcity;
	
	@FindBy(xpath="//p[contains(text(),'*State is required')]")
	@CacheLookup
	private WebElement errstate;
	
	@FindBy(xpath="//p[contains(text(),'*Zip Code is required')]")
	@CacheLookup
	private WebElement errzip;

	public WebElement getErrfname() {
		return errfname;
	}

	public WebElement getErrlname() {
		return errlname;
	}

	public WebElement getErrpwd() {
		return errpwd;
	}

	public WebElement getErrcpwd() {
		return errcpwd;
	}

	public WebElement getErrphnum() {
		return errphnum;
	}

	public WebElement getErremail() {
		return erremail;
	}

	public WebElement getErraddr() {
		return erraddr;
	}

	public WebElement getErrcity() {
		return errcity;
	}

	public WebElement getErrstate() {
		return errstate;
	}

	public WebElement getErrzip() {
		return errzip;
	}
}
