package signup;

import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import bean.SignUpFactory;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;


public class SignUpStepDef {
	private WebDriver driver;
	private SignUpFactory signUpFactory;
	
	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver",
				"D:\\Users\\shkoduku\\Desktop\\Module 4\\chromedriver.exe" );
		
		driver= new ChromeDriver();
	}
	
	@Given("^user is on 'SignUp' page$")
	public void user_is_on_SignUp_page() throws Throwable {
	    driver.get("C:\\Users\\shkoduku\\FLP\\asd\\asd\\src\\app\\signup\\signup.component.html");
	    signUpFactory = new SignUpFactory(driver);
	}

	@When("^user enters invalid first name$")
	public void user_enters_invalid_first_name() throws Throwable {
		signUpFactory.setCust_fname("");
		signUpFactory.setRegister();	   
	}

	@Then("^displays 'First Name is required'$")
	public void displays_First_Name_is_required() throws Throwable {
		String expectedMessage="Please fill out this field";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	    
	}

	@When("^user enters invalid last name$")
	public void user_enters_invalid_last_name() throws Throwable {
		signUpFactory.setCust_fname("Bala");
		signUpFactory.setCust_lname("");
		signUpFactory.setRegister();
	}

	@Then("^displays 'Last Name is required'$")
	public void displays_Last_Name_is_required() throws Throwable {
		String expectedMessage="Please fill out this field";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user enters invalid password$")
	public void user_enters_invalid_password() throws Throwable {
		signUpFactory.setCust_fname("Bala");
		signUpFactory.setCust_lname("Bhanu");
		signUpFactory.setCust_pwd("");
		signUpFactory.setRegister();
	}

	@Then("^displays 'Password is required'$")
	public void displays_Password_is_required() throws Throwable {
		String expectedMessage="Please fill out this field";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user enters invalid re-enter password$")
	public void user_enters_invalid_re_enter_password() throws Throwable {
		signUpFactory.setCust_fname("Bala");
		signUpFactory.setCust_lname("Bhanu");
		signUpFactory.setCust_pwd("123456");
		signUpFactory.setCust_cpwd("");
		signUpFactory.setRegister();
	}

	@Then("^displays 'Confirm Password is required'$")
	public void displays_Confirm_Password_is_required() throws Throwable {
		String expectedMessage="Please fill out this field";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user enters invalid mobile number$")
	public void user_enters_invalid_mobile_number() throws Throwable {
		signUpFactory.setCust_fname("Bala");
		signUpFactory.setCust_lname("Bhanu");
		signUpFactory.setCust_pwd("123456");
		signUpFactory.setCust_cpwd("123456");
		signUpFactory.setCust_phnum("");
		signUpFactory.setRegister();
	}

	@Then("^displays 'Mobile number is required'$")
	public void displays_Mobile_number_is_required() throws Throwable {
		Alert alt = driver.switchTo().alert();
		String msg = alt.getText();
		if (msg.equals("Please fill out this field")) {
			System.out.println("The text msg on alert box is: " + msg);
		} else {
			System.out.println("The text msg on alert box is not correct");
		}
		alt.accept();
	}

	@When("^user enters invalid email$")
	public void user_enters_invalid_email() throws Throwable {
		signUpFactory.setCust_fname("Bala");
		signUpFactory.setCust_lname("Bhanu");
		signUpFactory.setCust_pwd("123456");
		signUpFactory.setCust_cpwd("123456");
		signUpFactory.setCust_phnum("9988556622");
		signUpFactory.setCust_email("");
		signUpFactory.setRegister();
	}

	@Then("^displays 'Email is required'$")
	public void displays_Email_is_required() throws Throwable {
		Alert alt = driver.switchTo().alert();
		driver.manage().timeouts().implicitlyWait(360, TimeUnit.SECONDS);
		String msg = alt.getText();
		if (msg.equals("Please fill out this field")) {
			System.out.println("The text msg on alert box is: " + msg);
		} else {
			System.out.println("The text msg on alert box is not correct");
		}
		alt.accept();
	}

	@When("^user enters invalid address$")
	public void user_enters_invalid_address() throws Throwable {
		signUpFactory.setCust_fname("Bala");
		signUpFactory.setCust_lname("Bhanu");
		signUpFactory.setCust_pwd("123456");
		signUpFactory.setCust_cpwd("123456");
		signUpFactory.setCust_phnum("9988556622");
		signUpFactory.setCust_email("bala@gmail.com");
		signUpFactory.setCust_addr("");
		signUpFactory.setRegister();
	}

	@Then("^displays 'Address is required'$")
	public void displays_Address_is_required() throws Throwable {
		Alert alt = driver.switchTo().alert();
		driver.manage().timeouts().implicitlyWait(360, TimeUnit.SECONDS);
		String msg = alt.getText();
		if (msg.equals("Please fill out this field")) {
			System.out.println("The text msg on alert box is: " + msg);
		} else {
			System.out.println("The text msg on alert box is not correct");
		}
		alt.accept();
	}

	@When("^user enters invalid city$")
	public void user_enters_invalid_city() throws Throwable {
		signUpFactory.setCust_fname("Bala");
		signUpFactory.setCust_lname("Bhanu");
		signUpFactory.setCust_pwd("123456");
		signUpFactory.setCust_cpwd("123456");
		signUpFactory.setCust_phnum("9988556622");
		signUpFactory.setCust_email("bala@gmail.com");
		signUpFactory.setCust_addr("1-30-88/1A");
		signUpFactory.setCust_city("");
		signUpFactory.setRegister();
	}

	@Then("^displays 'City is required'$")
	public void displays_City_is_required() throws Throwable {
		Alert alt = driver.switchTo().alert();
		driver.manage().timeouts().implicitlyWait(360, TimeUnit.SECONDS);
		String msg = alt.getText();
		if (msg.equals("Please fill out this field")) {
			System.out.println("The text msg on alert box is: " + msg);
		} else {
			System.out.println("The text msg on alert box is not correct");
		}
		alt.accept();
	}

	@When("^user enters invalid state$")
	public void user_enters_invalid_state() throws Throwable {
		signUpFactory.setCust_fname("Bala");
		signUpFactory.setCust_lname("Bhanu");
		signUpFactory.setCust_pwd("123456");
		signUpFactory.setCust_cpwd("123456");
		signUpFactory.setCust_phnum("9988556622");
		signUpFactory.setCust_email("bala@gmail.com");
		signUpFactory.setCust_addr("1-30-88/1A");
		signUpFactory.setCust_city("Vizag");
		signUpFactory.setCust_state("");
		signUpFactory.setRegister();
	}

	@Then("^displays 'State is required'$")
	public void displays_State_is_required() throws Throwable {
		Alert alt = driver.switchTo().alert();
		driver.manage().timeouts().implicitlyWait(360, TimeUnit.SECONDS);
		String msg = alt.getText();
		if (msg.equals("Please fill out this field")) {
			System.out.println("The text msg on alert box is: " + msg);
		} else {
			System.out.println("The text msg on alert box is not correct");
		}
		alt.accept();
	}

	@When("^user enters invalid zipcode$")
	public void user_enters_invalid_zipcode() throws Throwable {
		signUpFactory.setCust_fname("Bala");
		signUpFactory.setCust_lname("Bhanu");
		signUpFactory.setCust_pwd("123456");
		signUpFactory.setCust_cpwd("123456");
		signUpFactory.setCust_phnum("9988556622");
		signUpFactory.setCust_email("bala@gmail.com");
		signUpFactory.setCust_addr("1-30-88/1A");
		signUpFactory.setCust_city("Vizag");
		signUpFactory.setCust_state("Andhra Pradesh");
		signUpFactory.setCust_zip("");
		signUpFactory.setRegister();
	}

	@Then("^displays 'Zip Code is required'$")
	public void displays_Zip_Code_is_required() throws Throwable {
		Alert alt = driver.switchTo().alert();
		driver.manage().timeouts().implicitlyWait(360, TimeUnit.SECONDS);
		String msg = alt.getText();
		if (msg.equals("Please fill out this field")) {
			System.out.println("The text msg on alert box is: " + msg);
		} else {
			System.out.println("The text msg on alert box is not correct");
		}
		alt.accept();
	}

	@When("^user enters valid details$")
	public void user_enters_valid_details() throws Throwable {
		signUpFactory.setCust_fname("Bala");
		signUpFactory.setCust_lname("Bhanu");
		signUpFactory.setCust_pwd("123456");
		signUpFactory.setCust_cpwd("123456");
		signUpFactory.setCust_phnum("9988556622");
		signUpFactory.setCust_email("bala@gmail.com");
		signUpFactory.setCust_addr("1-30-88/1A");
		signUpFactory.setCust_city("Vizag");
		signUpFactory.setCust_state("Andhra Pradesh");
		signUpFactory.setCust_zip("533101");
		signUpFactory.setRegister();
	}
	

@Then("^displays 'Successfully Submitted'$")
public void displays_Successfully_Submitted() throws Throwable {
	String expectedMessage="Account created successfully\\\\. Activation mail is sent to your addressed email";
	String actualMessage=driver.switchTo().alert().getText();
	Assert.assertEquals(expectedMessage, actualMessage);
	driver.switchTo().alert().accept();
	driver.close();
}



}
