package bean;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class SignUpFactory {
	
	WebDriver driver;
	
	@FindBy(name="cust_fname")
	@CacheLookup
	private WebElement cust_fname;
	
	@FindBy(name="cust_lname")
	@CacheLookup
	private WebElement cust_lname;
	
	@FindBy(xpath="//input[@id='cust_pwd']")
	@CacheLookup
	private WebElement cust_pwd;
	
	@FindBy(xpath="//input[@placeholder='Re-Enter Password']")
	@CacheLookup
	private WebElement cust_cpwd;
	
	@FindBy(xpath="//input[@placeholder='Enter Mobile Number']")
	@CacheLookup
	private WebElement cust_phnum;

	@FindBy(xpath="//input[@placeholder='Enter Email']")
	@CacheLookup
	private WebElement cust_email;
	
	@FindBy(xpath="//input[@placeholder='Enter Address']")
	@CacheLookup
	private WebElement cust_addr;
	
	@FindBy(xpath="//select[@name='cust_city']")
	@CacheLookup
	private WebElement cust_city;
	
	@FindBy(xpath="//select[@name='cust_state']")
	@CacheLookup
	private WebElement cust_state;
	
	@FindBy(xpath="//input[@placeholder='Enter Zip Code']")
	@CacheLookup
	private WebElement cust_zip;        
	
	@FindBy(xpath="//button[@class='btn btn-success btn-lg']")
	@CacheLookup
	private WebElement register;

	public SignUpFactory(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public WebDriver getDriver() {
		return driver;
	}

	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}

	public WebElement getCust_fname() {
		return cust_fname;
	}

	public void setCust_fname(String cust_fname) {
		this.cust_fname.sendKeys(cust_fname);
	}

	public WebElement getCust_lname() {
		return cust_lname;
	}

	public void setCust_lname(String cust_lname) {
		this.cust_lname.sendKeys(cust_lname);
	}

	public WebElement getCust_pwd() {
		return cust_pwd;
	}

	public void setCust_pwd(String cust_pwd) {
		this.cust_pwd.sendKeys(cust_pwd);
	}

	public WebElement getCust_cpwd() {
		return cust_cpwd;
	}

	public void setCust_cpwd(String cust_cpwd) {
		this.cust_cpwd.sendKeys(cust_cpwd);
	}

	public WebElement getCust_phnum() {
		return cust_phnum;
	}

	public void setCust_phnum(String cust_phnum) {
		this.cust_phnum.sendKeys(cust_phnum);
	}

	public WebElement getCust_email() {
		return cust_email;
	}

	public void setCust_email(String cust_email) {
		this.cust_email.sendKeys(cust_email);;
	}

	public WebElement getCust_addr() {
		return cust_addr;
	}

	public void setCust_addr(String cust_addr) {
		this.cust_addr.sendKeys(cust_addr);;
	}

	public WebElement getCust_city() {
		return cust_city;
	}

	public void setCust_city(String cust_city) {
		this.cust_city.sendKeys(cust_city);;
	}

	public WebElement getCust_state() {
		return cust_state;
	}

	public void setCust_state(String cust_state) {
		this.cust_state.sendKeys(cust_state);;
	}

	public WebElement getCust_zip() {
		return cust_zip;
	}

	public void setCust_zip(String cust_zip) {
		this.cust_zip.sendKeys(cust_zip);;
	}

	public WebElement getRegister() {
		return register;
	}

	public void setRegister() {
		this.register.click();
	}
	
	

	
}
