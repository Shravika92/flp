import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-chatwithus',
  templateUrl: './chatwithus.component.html',
  styleUrls: ['./chatwithus.component.css']
})
export class ChatwithusComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
