import { Component, OnInit, Injectable } from '@angular/core';
import { CustomerServiceService } from '../customer-service.service';
import { Customer } from '../customer';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})


@Injectable({
  providedIn: 'root'
})

export class SignupComponent implements OnInit{

  cust: Customer;
  proceed: boolean=false;

  constructor(private userService:CustomerServiceService) { 
    this.cust =new Customer();
  }

  ngOnInit() {
  }

  createCustomerAccount(data: Customer):void{
    this.cust.cust_fname=data.cust_fname;
    this.cust.cust_lname=data.cust_lname;
    this.cust.cust_pwd=data.cust_pwd;
    this.cust.cust_phnum=data.cust_phnum;
    this.cust.cust_email=data.cust_email;
    this.cust.cust_addr=data.cust_addr;
    this.cust.cust_city=data.cust_city;
    this.cust.cust_state=data.cust_state;
    this.cust.cust_zip=data.cust_zip;
    console.log(this.cust);
    this.userService.createCustomerAccount(this.cust).subscribe(data => {
      alert("Account created successfully. Activation mail is sent to your addressed email");
    });
  }

  flag=false;
  cust_fname;cust_lname;cust_phnum;cust_email;cust_addr;cust_city;cust_state;cust_zip;

  c:Customer=new Customer;
  display(c:Customer){
    this.flag=true;
    this.cust_fname=c.cust_fname;
    this.cust_lname=c.cust_lname;
    this.cust_phnum=c.cust_phnum;
    this.cust_email=c.cust_email;
    this.cust_addr=c.cust_addr;
    this.cust_city=c.cust_city;
    this.cust_state=c.cust_state;
    this.cust_zip=c.cust_zip;
  }
}


