import { Injectable } from "@angular/core";
import { HttpClient } from '@angular/common/http';
import { Customer } from "./customer";

@Injectable({
    providedIn:'root'
})

export class CustomerServiceService{
    constructor(private httpClient:HttpClient){ }

    public createCustomerAccount(details: Customer) {
        console.log(details);
        return this.httpClient.post<Customer>("http://localhost:8050/createaccount",details);
    }

    // public display(cust_fname){
    //     console.log(cust_fname);
    //     return this.httpClient.get<Customer>("http://localhost:8050/show/" +cust_fname)
    // }
}
