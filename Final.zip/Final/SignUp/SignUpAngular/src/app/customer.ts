export class Customer
{
    public cust_fname: string;
    public cust_lname: string;
    public cust_pwd: string;
    public cust_phnum: string;
    public cust_email: string;
    public cust_addr: string;
    public cust_city: string;
    public cust_state: string;
    public cust_zip: string;
}