package com.cg.customer.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cg.customer.bean.Customer123;

@Repository
public interface CustomerDao extends JpaRepository<Customer123, Integer> {

	@Query("from Customer123 where cust_fname=:name")
	Customer123 findByName(@Param("name") String cust_fname);

}
