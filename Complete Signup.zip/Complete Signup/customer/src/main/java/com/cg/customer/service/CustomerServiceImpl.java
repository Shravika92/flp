package com.cg.customer.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.customer.bean.Customer123;
import com.cg.customer.dao.CustomerDao;
import com.cg.customer.exception.CustomerException;

@Service
public class CustomerServiceImpl implements CustomerService {

	@Autowired
	CustomerDao customerDao;
	
	@Override
	public Customer123 addCustomer(Customer123 cust) throws CustomerException {
		try {
			return customerDao.save(cust);
		}
		catch(Exception ex)
		{
			throw new CustomerException("Check the details properly");
		}
	}

	@Override
	public Customer123 show(int id) throws CustomerException{
		try
		{
		return customerDao.findById(id).get();
		}
		catch(Exception ex)
		{
			throw new CustomerException("Pleas enter valid Id");
		}
	}

	@Override
	public List<Customer123> allCustomer(Customer123 cust) throws CustomerException {
		try {
			return customerDao.findAll();
		}
		catch(Exception ex)
		{
			throw new CustomerException("Check the details properly");
		}
	}

}
