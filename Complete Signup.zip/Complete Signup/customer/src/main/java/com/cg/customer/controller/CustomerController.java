package com.cg.customer.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.customer.bean.Customer123;
import com.cg.customer.exception.CustomerException;
import com.cg.customer.service.CustomerService;

@CrossOrigin(origins="http://localhost:4200")
@RestController
public class CustomerController {

	@Autowired
	CustomerService customerService;
	
	@RequestMapping(value = "/createaccount", method = RequestMethod.POST)
	public Customer123 addCustomer(@RequestBody Customer123 cust) throws CustomerException {
		return customerService.addCustomer(cust);
	}
	
	@RequestMapping(value = "/view", method = RequestMethod.GET)
	public List<Customer123> allCustomer(Customer123 cust) throws CustomerException {
		return customerService.allCustomer(cust);
	}
	
	@RequestMapping(value = "/show/{id}", method= RequestMethod.GET)
  	public Customer123 show(@PathVariable int id) throws CustomerException {
  		return customerService.show(id);
  	}
}
