package com.cg.customer.service;

import java.util.List;

import com.cg.customer.bean.Customer123;
import com.cg.customer.exception.CustomerException;

public interface CustomerService {

	public Customer123 addCustomer(Customer123 cust) throws CustomerException;

	public Customer123 show(int id)throws CustomerException;

	public List<Customer123> allCustomer(Customer123 cust) throws CustomerException;

}
