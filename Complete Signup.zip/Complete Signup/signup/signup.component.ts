import { Component, OnInit, Injectable } from '@angular/core';
import { CustomerServiceService } from '../customer-service.service';
import { Customer } from '../customer';
import { Router } from '@angular/router';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})


@Injectable({
  providedIn: 'root'
})

export class SignupComponent implements OnInit{

  cust: Customer;

  constructor(private userService:CustomerServiceService) { 
    this.cust =new Customer();
  }

  ngOnInit() {
  }

  createCustomerAccount(data):void{
    this.cust.cust_fname=data.cust_fname;
    this.cust.cust_lname=data.cust_lname;
    this.cust.cust_pwd=data.cust_pwd;
    this.cust.cust_phnum=data.cust_phnum;
    this.cust.cust_email=data.cust_email;
    this.cust.cust_addr=data.cust_addr;
    this.cust.cust_city=data.cust_city;
    this.cust.cust_state=data.cust_state;
    this.cust.cust_zip=data.cust_zip;

    this.userService.createCustomerAccount(this.cust).subscribe(data => {
      alert("Account created successfully.");
    });
  }
}
