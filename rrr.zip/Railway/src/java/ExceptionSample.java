/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author CIIT
 */
public class ExceptionSample extends Exception {
    
    int i;
    int k[]={1,2,3};
    void add(int j)
    {
    try{
        
    i=10/j;
        System.out.println(i);
        
     
    
      for(int l=0; l<=j;l++)
      {
      
          System.out.println(k[l]);
      }
    }catch(ArithmeticException e )
    {
    
        System.out.println(e);
        j++; 
        i=10/j;
         
       System.out.println(i);
    }
    catch(ArrayIndexOutOfBoundsException e1)
    {
    
        System.out.println("exception occured");
    
    }
    finally
    {
        System.out.println("finally block");
    }
    
    }
    
    public static void main(String args[])
    {
    ExceptionSample a=new ExceptionSample();
    a.add(0);
    
    
    
    }
    
    
}
