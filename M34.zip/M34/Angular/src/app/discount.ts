export class Discount {
    public id: number;
    public prodname: string;
    public prodcategory: string;
    public price: number;
    public discount: number;
    public discounted: number;
}