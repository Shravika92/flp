import { Component, OnInit } from '@angular/core';
import { DiscountServiceService } from '../discount-service.service';
import { Discount } from '../discount';
@Component({
  selector: 'app-success',
  templateUrl: './success.component.html',
  styleUrls: ['./success.component.css']
})
export class SuccessComponent implements OnInit {

  discount: Discount;
  constructor(private userService:DiscountServiceService) {   }

  ngOnInit() {
    this.discount = new Discount();
  }

  show(id){
    this.userService.show(id).subscribe(data =>(this.discount=data));
  }

}
