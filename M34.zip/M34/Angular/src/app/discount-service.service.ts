import { Injectable } from "@angular/core";
import { HttpClient } from '@angular/common/http';
import { Discount } from "./discount";
@Injectable({
    providedIn:'root'
})

export class DiscountServiceService{

    constructor(private httpClient:HttpClient){ }

    public show(id) {
        console.log(id);
        return this.httpClient.get<Discount>("http://localhost:8050/view/" +id);
    }
}