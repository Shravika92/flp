import { Discount } from "./discount";

describe('Customer',() => {
    it('should create an instance',() => {
        expect(new Discount()).toBeTruthy();
    });
});